import os
import pandas as pd

# 文件夹路径
folder_path = r'D:\算法设计与分析\MPAGAFS\result'

# 获取所有xlsx文件（可根据需要排序）
xlsx_files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]
xlsx_files.sort()  # 可选：按文件名排序合并

# 初始化空列表用于存储每个表格的数据
df_list = []

# 遍历每个文件并读取
for file in xlsx_files:
    file_path = os.path.join(folder_path, file)
    df = pd.read_excel(file_path)
    df.insert(0, 'source', file)  # 在第一列插入文件名作为来源标记
    df_list.append(df)

# 按行合并所有DataFrame
merged_df = pd.concat(df_list, axis=0, ignore_index=True)

# 保存合并后的文件
output_path = os.path.join(folder_path, 'merged_result_with_source.xlsx')
merged_df.to_excel(output_path, index=False)

print(f"合并完成，文件已保存到: {output_path}")
